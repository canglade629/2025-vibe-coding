Download the entire folder as Zip, and import it into your go/fevm workspace.

Connect to serverless compute, run all cells, and follow the instructions in cells 10 and 11.